
import { LockedContent, Transaction, User, AuthSession, WithdrawalRequest } from '../types';

const STORAGE_KEY = 'paylock_db_v1';
const TRANSACTIONS_KEY = 'paylock_transactions_v1';
const BALANCE_KEY = 'paylock_balance_v1';
const USERS_KEY = 'paylock_users_v1';
const SESSION_KEY = 'paylock_session_v1';
const WITHDRAWALS_KEY = 'paylock_withdrawals_v1';

// Configuration MoneyFusion
const MONEYFUSION_PAY_URL = "https://www.pay.moneyfusion.net/pay";
const MONEYFUSION_NOTIF_URL = "https://www.pay.moneyfusion.net/paiementNotif";

// Format utility
export const formatPrice = (amount: number, currency: string = 'USD') => {
  if (currency === 'XOF') return `${amount.toLocaleString()} CFA`;
  if (currency === 'EUR') return `€${amount.toFixed(2)}`;
  return `$${amount.toFixed(2)}`;
};

// API MoneyFusion: Initialiser le paiement
export const initiateMoneyFusionPayment = async (data: {
  price: number;
  title: string;
  phone: string;
  clientName: string;
  contentId: string;
}) => {
  const paymentData = {
    totalPrice: data.price,
    article: [
      {
        [data.title]: data.price,
      },
    ],
    personal_Info: [
      {
        contentId: data.contentId,
      },
    ],
    numeroSend: data.phone,
    nomclient: data.clientName,
    return_url: window.location.href,
    webhook_url: "https://your-domain.com/webhook", // À configurer si vous avez un backend
  };

  try {
    const response = await fetch(MONEYFUSION_PAY_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(paymentData),
    });
    return await response.json();
  } catch (error) {
    console.error("MoneyFusion API Error:", error);
    throw error;
  }
};

// API MoneyFusion: Vérifier l'état (Polling)
export const checkMoneyFusionStatus = async (token: string) => {
  try {
    const response = await fetch(`${MONEYFUSION_NOTIF_URL}/${token}`);
    return await response.json();
  } catch (error) {
    console.error("Status Check Error:", error);
    throw error;
  }
};

// Authentication Management
export const signup = (name: string, email: string, password: string): AuthSession => {
  const users: (User & {password: string})[] = JSON.parse(localStorage.getItem(USERS_KEY) || '[]');
  
  if (users.find(u => u.email === email)) {
    throw new Error("User with this email already exists");
  }

  const role: 'user' | 'admin' = (email === 'admin@paylock.com' || users.length === 0) ? 'admin' : 'user';

  const newUser = {
    id: generateId(),
    name,
    email,
    password,
    role
  };

  localStorage.setItem(USERS_KEY, JSON.stringify([...users, newUser]));
  
  const session: AuthSession = {
    user: { id: newUser.id, name: newUser.name, email: newUser.email, role: newUser.role },
    token: `mock-token-${newUser.id}`
  };
  
  localStorage.setItem(SESSION_KEY, JSON.stringify(session));
  return session;
};

export const login = (email: string, password: string): AuthSession => {
  const users: (User & {password: string})[] = JSON.parse(localStorage.getItem(USERS_KEY) || '[]');
  const user = users.find(u => u.email === email && u.password === password);
  
  if (!user) {
    throw new Error("Invalid email or password");
  }

  const session: AuthSession = {
    user: { id: user.id, name: user.name, email: user.email, role: user.role },
    token: `mock-token-${user.id}`
  };
  
  localStorage.setItem(SESSION_KEY, JSON.stringify(session));
  return session;
};

export const logout = (): void => {
  localStorage.removeItem(SESSION_KEY);
};

export const getCurrentSession = (): AuthSession | null => {
  const data = localStorage.getItem(SESSION_KEY);
  return data ? JSON.parse(data) : null;
};

export const getAllUsers = (): User[] => {
  const users: (User & {password: string})[] = JSON.parse(localStorage.getItem(USERS_KEY) || '[]');
  return users.map(({password, ...u}) => u);
};

// Content Management
export const saveContent = (content: LockedContent): void => {
  const existing = getContentList();
  const updated = [...existing, content];
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  } catch (e) {
    console.error("Storage quota exceeded.", e);
    alert("Media too large for browser demo storage. Please use a smaller file.");
  }
};

export const getContentList = (): LockedContent[] => {
  const data = localStorage.getItem(STORAGE_KEY);
  return data ? JSON.parse(data) : [];
};

export const getContentById = (id: string): LockedContent | undefined => {
  const list = getContentList();
  return list.find((item) => item.id === id);
};

export const deleteContentGlobal = (id: string): void => {
  const list = getContentList();
  const filtered = list.filter(item => item.id !== id);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(filtered));
};

// Financial & Transaction Management
export const recordTransaction = (contentId: string, amount: number, contentTitle: string, currency: string = 'USD'): void => {
  const transactions = getTransactions();
  const fee = amount * 0.10; // 10% platform fee
  const net = amount - fee;

  const newTx: Transaction = {
    id: generateId(),
    contentId,
    contentTitle,
    amount,
    netAmount: net,
    currency,
    timestamp: Date.now(),
    buyerMasked: `User-${Math.floor(Math.random() * 1000)}`
  };

  try {
    localStorage.setItem(TRANSACTIONS_KEY, JSON.stringify([newTx, ...transactions]));
    const currentBalance = getBalance();
    localStorage.setItem(BALANCE_KEY, (currentBalance + net).toString());
  } catch (e) {
    console.error("Storage error recording transaction", e);
  }
};

export const getTransactions = (): Transaction[] => {
  const data = localStorage.getItem(TRANSACTIONS_KEY);
  return data ? JSON.parse(data) : [];
};

export const getBalance = (): number => {
  const bal = localStorage.getItem(BALANCE_KEY);
  return bal ? parseFloat(bal) : 0;
};

// Withdrawal Management
export const createWithdrawalRequest = (data: { amount: number, currency: string, method: string, accountNumber: string, name: string }): void => {
  const session = getCurrentSession();
  if (!session) return;

  const requests = getWithdrawalRequests();
  const newRequest: WithdrawalRequest = {
    id: generateId(),
    userId: session.user.id,
    userName: data.name,
    amount: data.amount,
    currency: data.currency,
    method: data.method,
    accountNumber: data.accountNumber,
    status: 'pending',
    createdAt: Date.now()
  };

  localStorage.setItem(WITHDRAWALS_KEY, JSON.stringify([newRequest, ...requests]));
  
  const currentBalance = getBalance();
  localStorage.setItem(BALANCE_KEY, (currentBalance - data.amount).toString());
};

export const getWithdrawalRequests = (): WithdrawalRequest[] => {
  const data = localStorage.getItem(WITHDRAWALS_KEY);
  return data ? JSON.parse(data) : [];
};

export const updateWithdrawalStatus = (id: string, status: 'completed' | 'rejected'): void => {
  const requests = getWithdrawalRequests();
  const updated = requests.map(req => {
    if (req.id === id) {
      if (status === 'rejected' && req.status === 'pending') {
        const currentBalance = getBalance();
        localStorage.setItem(BALANCE_KEY, (currentBalance + req.amount).toString());
      }
      return { ...req, status };
    }
    return req;
  });
  localStorage.setItem(WITHDRAWALS_KEY, JSON.stringify(updated));
};

export const withdrawFunds = (): Promise<void> => {
  return new Promise((resolve) => {
    localStorage.setItem(BALANCE_KEY, '0');
    resolve();
  });
};

export const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = (error) => reject(error);
  });
};

export const generateId = (): string => {
  return Math.random().toString(36).substring(2, 10);
};

// Backup & Restore System
export const exportDatabase = (): string => {
  const data = {
    version: '1.0',
    timestamp: Date.now(),
    content: localStorage.getItem(STORAGE_KEY),
    transactions: localStorage.getItem(TRANSACTIONS_KEY),
    balance: localStorage.getItem(BALANCE_KEY),
    users: localStorage.getItem(USERS_KEY),
    withdrawals: localStorage.getItem(WITHDRAWALS_KEY),
  };
  return JSON.stringify(data, null, 2);
};

export const importDatabase = (jsonString: string): boolean => {
  try {
    const data = JSON.parse(jsonString);
    if (!data.version) throw new Error("Invalid backup file");

    if (data.content) localStorage.setItem(STORAGE_KEY, data.content);
    if (data.transactions) localStorage.setItem(TRANSACTIONS_KEY, data.transactions);
    if (data.balance) localStorage.setItem(BALANCE_KEY, data.balance);
    if (data.users) localStorage.setItem(USERS_KEY, data.users);
    if (data.withdrawals) localStorage.setItem(WITHDRAWALS_KEY, data.withdrawals);
    
    return true;
  } catch (e) {
    console.error("Import failed", e);
    return false;
  }
};
