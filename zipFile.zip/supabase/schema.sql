<<<<<<< SEARCH
=======
-- Enable UUID extension
create extension if not exists "uuid-ossp";

-- 1. Users Table
create table public.users (
  id uuid default uuid_generate_v4() primary key,
  email text unique not null,
  password text not null, -- In production, store hashed passwords!
  name text,
  role text default 'user' check (role in ('user', 'admin')),
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- 2. Content Table
create table public.content (
  id uuid default uuid_generate_v4() primary key,
  creator_id uuid references public.users(id) not null,
  title text not null,
  description text,
  price numeric not null,
  currency text default 'USD',
  image_base64 text, -- Note: For prod, use Supabase Storage and store URL here
  mime_type text,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- 3. Transactions Table
create table public.transactions (
  id uuid default uuid_generate_v4() primary key,
  content_id uuid references public.content(id),
  content_title text,
  amount numeric not null,
  net_amount numeric not null,
  currency text,
  buyer_masked text,
  timestamp bigint, -- Storing JS timestamp for compatibility
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- 4. Withdrawals Table
create table public.withdrawals (
  id uuid default uuid_generate_v4() primary key,
  user_id uuid references public.users(id),
  user_name text,
  amount numeric not null,
  currency text,
  method text,
  account_number text,
  status text default 'pending' check (status in ('pending', 'completed', 'rejected')),
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Row Level Security (Optional for Server-side usage but good practice)
alter table public.users enable row level security;
alter table public.content enable row level security;
alter table public.transactions enable row level security;
alter table public.withdrawals enable row level security;
>>>>>>>
