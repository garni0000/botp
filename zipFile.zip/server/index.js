<<<<<<< SEARCH
=======
import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { createClient } from '@supabase/supabase-js';

dotenv.config();

const app = express();
const PORT = 5000;

// Supabase Configuration
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_KEY; // Use Service Key for backend operations

if (!supabaseUrl || !supabaseKey) {
  console.error("Missing Supabase credentials in .env");
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

app.use(cors());
app.use(express.json({ limit: '50mb' }));

// --- Routes ---

// 1. Auth
app.post('/api/auth/signup', async (req, res) => {
  const { name, email, password } = req.body;
  
  // Check if user exists
  const { data: existing } = await supabase.from('users').select('id').eq('email', email).single();
  if (existing) {
    return res.status(400).json({ message: 'User already exists' });
  }

  // Determine role (first user is admin)
  const { count } = await supabase.from('users').select('*', { count: 'exact', head: true });
  const role = (email === 'admin@paylock.com' || count === 0) ? 'admin' : 'user';

  const { data: newUser, error } = await supabase
    .from('users')
    .insert([{ name, email, password, role }]) // Note: Password should be hashed in real app
    .select()
    .single();

  if (error) return res.status(500).json({ message: error.message });

  const { password: _, ...userWithoutPass } = newUser;
  res.json({ user: userWithoutPass, token: `mock-jwt-${newUser.id}` });
});

app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body;
  
  const { data: user, error } = await supabase
    .from('users')
    .select('*')
    .eq('email', email)
    .eq('password', password) // Note: Compare hashes in real app
    .single();

  if (error || !user) {
    return res.status(401).json({ message: 'Invalid credentials' });
  }

  const { password: _, ...userWithoutPass } = user;
  res.json({ user: userWithoutPass, token: `mock-jwt-${user.id}` });
});

// 2. Content
app.get('/api/content', async (req, res) => {
  const { data, error } = await supabase
    .from('content')
    .select('*')
    .order('created_at', { ascending: false });
  
  if (error) return res.status(500).json({ message: error.message });
  
  // Map snake_case to camelCase for frontend compatibility
  const mapped = data.map(item => ({
    ...item,
    imageBase64: item.image_base64,
    mimeType: item.mime_type,
    creatorId: item.creator_id,
    createdAt: new Date(item.created_at).getTime()
  }));
  
  res.json(mapped);
});

app.get('/api/content/:id', async (req, res) => {
  const { data: item, error } = await supabase
    .from('content')
    .select('*')
    .eq('id', req.params.id)
    .single();

  if (error || !item) return res.status(404).json({ message: 'Content not found' });

  const mapped = {
    ...item,
    imageBase64: item.image_base64,
    mimeType: item.mime_type,
    creatorId: item.creator_id,
    createdAt: new Date(item.created_at).getTime()
  };

  res.json(mapped);
});

app.post('/api/content', async (req, res) => {
  const { title, description, price, currency, imageBase64, mimeType, creatorId } = req.body;
  
  const { data, error } = await supabase
    .from('content')
    .insert([{
      title,
      description,
      price,
      currency,
      image_base64: imageBase64,
      mime_type: mimeType,
      creator_id: creatorId
    }])
    .select()
    .single();

  if (error) return res.status(500).json({ message: error.message });
  
  res.json({ ...data, id: data.id });
});

// 3. Transactions
app.post('/api/transactions', async (req, res) => {
  const { contentId, amount, contentTitle, currency } = req.body;
  
  const netAmount = amount * 0.9; // 10% fee
  const buyerMasked = `User-${Math.floor(Math.random() * 1000)}`;
  const timestamp = Date.now();

  const { data, error } = await supabase
    .from('transactions')
    .insert([{
      content_id: contentId,
      content_title: contentTitle,
      amount,
      net_amount: netAmount,
      currency,
      buyer_masked: buyerMasked,
      timestamp
    }])
    .select()
    .single();

  if (error) return res.status(500).json({ message: error.message });

  res.json({
    ...data,
    contentId: data.content_id,
    contentTitle: data.content_title,
    netAmount: data.net_amount,
    buyerMasked: data.buyer_masked
  });
});

// Start Server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
  console.log(`Connected to Supabase: ${supabaseUrl}`);
});
>>>>>>>
